#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define SHMSZ 20000

char final_string[400];
char message[400];
char *shm, *s;

void write_to_buffer(char * message); //method for writing to shared memory/buffer

int main() {
    int shmid; //shared memory id
    key_t key; //shared memory key
    
    /* We'll name our shared memory segment "56 8".
    */
    key = 568;
    /*
    * Create the segment.
    */
    if ((shmid = shmget(key, SHMSZ , IPC_CREAT | 0666)) < 0) {
    exit(1);
    printf("shmget error");
    }
    /*
    * Now we attach the segment to our data space.
    */
    if ((shm = shmat(shmid, NULL, 0)) == (char *) -1) {
    printf("shmat error");
    exit(1);
    }

    while(1){
        while (*shm != '*')
            sleep(1);
        for (s = shm; *s != '\0'; s++)
            putchar(*s);
            putchar('\n');
        printf("\n>> ");
        
        
        
        scanf("%s",&message);
        write_to_buffer(message);
        
    }

}

void write_to_buffer(char * message)
{
    strcat(final_string,".");
    strcat(final_string,message);
    memcpy(shm,final_string,100);

}

